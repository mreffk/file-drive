<?php

require("db.php");

$name = $_FILES['vid']['name'];

$f_img = $_FILES['vid']['tmp_name'];

$img_dir = "docs/";

$img_name = $img_dir . basename($_FILES['vid']["name"]);

$img_accepted = array("pdf","docx","ppt","pptx","doc");

$img_ext = strtolower(pathinfo($img_name,PATHINFO_EXTENSION));

if( in_array($img_ext,$img_accepted) ) {

	$send_data = new Database();

	$query = "INSERT INTO `up` (`name`) VALUES (?)";

	$send_data->create_data($query,"s",array($name));

	move_uploaded_file($f_img,$img_dir.$name);

}

?>