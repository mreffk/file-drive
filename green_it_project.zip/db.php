<?php

class Database {

protected $dbuser;

protected $dbhost;

protected $dbpass;

protected $dbname;

// CONNECTION CONSTRUCT

public function __construct($dbuser ='root', $dbpass ='', $dbname ='p', $dbhost ='localhost') {

			$this->dbuser = $dbuser;
			$this->dbpass = $dbpass;
			$this->dbname = $dbname;
			$this->dbhost = $dbhost;
		}

// CONNECTION FUNCTION

protected function connect() {

return new mysqli($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname);

		}

// REDIRECT

function redirect($url) {

	header("Location:" . $url);

	exit();
}

// SHOW ERROR MESSAGE

function err_mssg($type, $message) {

	return $message;
}

// VALIDATE NAME

function validate_name($data)

	{

		$name = $data['fname'];

 return preg_match("/^[a-zA-Z]+ [a-zA-Z ]*$/", $name);

	}

// VALIDATE EMAIL 

function validate_email($data)

	{

		$email = $data['email'];

 return preg_match("/^[a-zA-Z0-9._-]+@[st]{2}+\.[futminna]{8}+\.[edu]{3}+\.[ng]{2}$/", $email);

}

// IF EMAIL EXISTS

function email_exists($data) {

	$email = $data['email'];

	$query = "SELECT email FROM users WHERE email = '$email'";

	$check = $this->rowsAffected($query);

	return $check;
}

// AFFECTED ROWS

function rowsAffected($query) {

	$this->conn = $this->connect();

	$sql = $this->conn->prepare($query);

	$sql->execute();

	$sql->store_result();

	if($sql->num_rows > 0) {

		return true;
	}

	else {

		return false;
	}

	$sql->free_result();
}

function numRows($query) {

	$this->conn = $this->connect();

	$sql = $this->conn->prepare($query);

	$sql->execute();

	$sql->store_result();

	$rows = $sql->num_rows;

	return $rows;
}

// CREATE DATA

function create_data($query, $param_type, $param_value_array) {

	$this->conn = $this->connect();

	$sql = $this->conn->prepare($query);

	$this->bindParam($sql, $param_type, $param_value_array);

    $sql->execute();

if($this->conn->connect_error) {
 
	die('Error connecting to the server');
}

}

// BIND PARAMETERS FUNCTION

function bindParam($sql, $param_type, $param_value_array) {

	$sql->bind_param($param_type, ...$param_value_array);

}


// GET USER DATA ASSOCIATION

function userDataQuery($query) {

	$this->conn = $this->connect();

	$sql = $this->conn->prepare($query);

	$sql->execute();

	$getAll = $sql->get_result();

	return $getAll;
}

function deleteQ($param_value_array) {

	$this->conn = $this->connect();

	$query = "DELETE FROM up WHERE id = ?";

	$sql = $this->conn->prepare($query);

	$this->bindParam($sql, "i", $param_value_array);

	$sql->execute();

	return true;
}

function trashQ($param_value_array) {

	$this->conn = $this->connect();

	$query = "UPDATE up SET type = 'trash' WHERE id = ?";

	$sql = $this->conn->prepare($query);

	$this->bindParam($sql, "i", $param_value_array);

	$sql->execute();

	return true;
}

function grantPerm($param_value_array) {

	$this->conn = $this->connect();

	$query = "UPDATE up SET access = ? WHERE id = ?";

	$sql = $this->conn->prepare($query);

	$this->bindParam($sql, "si", $param_value_array);

	$sql->execute();

	return true;

}

// CREATE NEW USER 

function new_user($name, $email, $dept, $type, $pass) {

$query = "INSERT INTO users(name,email,dept,type,password) VALUES(?, ?, ?, ?, ?)";

$allOk = $this->create_data($query, 'sssss', array($name, $email, $dept, $type, $pass));

return $allOk;

}

// LOGIN AUTHENTICATION

function login_auth($query, $param_type, $param_value_array) {

	$this->conn = $this->connect();

	$sql = $this->conn->prepare($query);

	$this->bindParam($sql, $param_type, $param_value_array);

	$sql->execute();

	$sql->store_result();

	if($sql->num_rows === 1) {

		return true;
	}

	else {

		return false;
	}

	$sql->free_result();
}

// LOGIN USER

function login_user($email, $pass) {

$query = "SELECT email, password FROM users WHERE email = ? AND password = ?";

$isValid = $this->login_auth($query, 'ss', array($email, $pass));

return $isValid;

}

// GET USER DATA

function getUserInfo($session) {

$query = "SELECT * FROM users WHERE email = '$session'";

$getUser = $this->userDataQuery($query);

return $getUser;

}

// END CLASS

}