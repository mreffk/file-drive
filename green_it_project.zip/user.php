<!--

  // Login and Signup

  -->

  <?php 

  session_start();

  if(isset($_POST['reg'])) {

    $name = $_POST['fname'];

    $email = $_POST['email'];

    $dept = $_POST['dept'];

    $type = $_POST['type'];

    $pass = '@#' . md5(sha1($_POST['password'])) . '$';

    require_once("db.php");

  $reg = new Database;

  if ($reg->validate_name($_POST) && $reg->validate_email($_POST) == true) {

  if ($reg->email_exists($_POST) == false) {

    $reg->new_user($name,$email,$dept,$type,$pass);

    $success = true;
}
  
 else if ($reg->email_exists($_POST) == true) {

    $user_Exists = $reg->err_mssg('error','User already exists.');

    // Save session if error occurs

    $_SESSION['fname'] = $_POST['fname'];

    $_SESSION['email'] = $_POST['email'];
  }
}
  else {

      $tryAgain = $reg->err_mssg('error', "Check that all fields are correct.");

    // Save session if error occurs

    $_SESSION['fname'] = $_POST['fname'];

    $_SESSION['email'] = $_POST['email'];

    }

  }

if(isset($_POST['signin'])) {

  require_once("db.php");

  $login = new Database();

  $email = $_POST['email'];

  $pass = '@#' . md5(sha1($_POST['password'])) . '$';

  if($login->validate_email($_POST) && $login->login_user($email, $pass) == true) {

    $_SESSION['user'] = $email;

    $session = $_SESSION['user'];

    $login->redirect("index.php");
  }

  else if($login->validate_email($_POST) == false) {

    $invalid_Format = $login->err_mssg('error','Kindly enter a valid email.');
  }

  else {

    $loginFailed = $login->err_mssg('error','Sorry! Invalid login.');
  }
}

  ?>

<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Data center"> 
    <meta name="keywords" content="Data center">
    
    <title>Data Center</title>

    <link rel="stylesheet" href="css/style.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/carousel.js"></script>
    
</head>

<body class="uform">

<script>

  $(document).ready(function() {

// User input

var input = document.getElementById("userPw");

var fb = document.getElementById("fback");

// Event Listener for capslock

input.addEventListener("keyup", function(event) {

  if(event.getModifierState("CapsLock")) {

    $('#fback').show();
  } 

  else {

    $('#fback').hide();

  }

})

});

</script>

<div class="container">

  <!-- User -->

  <?php if(isset($loginFailed)) { ?>

  <div id="reg-s" class="row mt-3">

  <div id="failed" class="col-lg-3 col-md-10 col-sm-12 mx-auto animated slideInDown shadow-sm">

    <button type="button" class="close" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>

      <h6><?php echo $loginFailed?></h6>

    </div>

  </div>

<?php }

else if(isset($invalid_Format)) {

?>

<div id="reg-s" class="row mt-3">

  <div id="failed" class="col-lg-3 col-md-10 col-sm-12 mx-auto animated slideInRight shadow-sm">

    <button type="button" class="close" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>

      <h6><?php echo $invalid_Format?></h6>

    </div>

  </div>

  <?php } 

  else if(isset($user_Exists)) { ?>

    <script>

  $(document).ready(function() {

    $('#login-tab').removeClass('active');

    $('#login').removeClass('active');

    $('#signup-tab').addClass('active');

    $('#signup').addClass('show active');
  });

</script>

    <div id="reg-s" class="row mt-3">

  <div id="failed" class="col-lg-3 col-md-10 col-sm-12 mx-auto animated slideInRight shadow-sm">

    <button type="button" class="close" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>

      <h6><?php echo $user_Exists?></h6>

    </div>

  </div>

<?php } ?>

  <?php if(isset($success)) { ?>

  <div id="reg-s" class="row mt-3">

  <div id="suk" class="col-lg-3 col-md-10 col-sm-12 mx-auto animated slideInRight shadow-sm">

    <button type="button" class="close" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>

      <h6>You have successfully registered <i class="fa fa-check-circle fa-green"></i></h6>

    </div>

  </div>

<?php 

} 

else if(isset($connError)) { ?>

  <script>

  $(document).ready(function() {

    $('#login-tab').removeClass('active');

    $('#login').removeClass('active');

    $('#signup-tab').addClass('active');

    $('#signup').addClass('show active');
  });

</script>



<div id="reg-s" class="row mt-3">

  <div id="failed" class="col-lg-3 col-md-10 col-sm-12 mx-auto animated slideInRight shadow-sm">

    <button type="button" class="close" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>

      <h6><?php echo $connError?></h6>

    </div>

  </div>

<?php 

}

else if(isset($tryAgain)) { ?>

<script>

  $(document).ready(function() {

    $('#login-tab').removeClass('active');

    $('#login').removeClass('active');

    $('#signup-tab').addClass('active');

    $('#signup').addClass('show active');
  });

</script>

<div id="reg-s" class="row mt-3">

  <div id="failed" class="col-lg-3 col-md-10 col-sm-12 mx-auto animated slideInRight shadow-sm">

    <button type="button" class="close" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>

      <h6><?php echo('<i class="fa fa-info-circle fa-red"></i> ') . $tryAgain?></h6>

    </div>

  </div>

<?php } ?>

  <div id="stab" class="row">

    <div class="col-lg-4 col-md-10 col-sm-12 mtop-sm mx-auto">

      <!-- User Tabs -->

  <ul class="nav nav-pills nav-fill p-2" id="myTab" role="tablist">
  <li class="nav-item p-1">
    <a class="nav-link active brad" id="login-tab" data-toggle="tab" href="#login" role="tab" aria-controls="login" aria-selected="true">Login</a>
  </li>
  <li class="nav-item p-1">
    <a class="nav-link brad" id="signup-tab" data-toggle="tab" href="#signup" role="tab" aria-controls="signup" aria-selected="false">Signup</a>
  </li>
</ul>

</div>

</div>

<!-- Tab Contents -->

  <div class="row">

    <div class="mauto col-lg-4  col-md-10 col-sm-12 p-3 mt-3 mx-auto">

<div class="tab-content" id="userAccount">

  <!-- Login tab -->

  <div class="tab-pane fade show active" id="login" role="tabpanel" aria-labelledby="login-tab">

<h5 class="login">Signin to your account</h5>

<form method="post">

  <label>Student Email</label>

    <div class="input-group mb-2">

  <div class="input-group-prepend">

    <button class="btn btn-success"><i class="fa fa-envelope"></i></button>

  </div>

      <input type="email" id="user_em" class="form-control userIn" placeholder="* Email Address" name="email" autocomplete="user-email" required>

    </div>

    <label>Password</label>

    <div class="input-group has-f-f mb-2">

  <div class="input-group-prepend">

    <button class="btn btn-success"><i class="fa fa-lock"></i></button>

  </div>

      <input type="password" id="user_pw" class="form-control userIn" placeholder="* Password" name="password" autocomplete="user-password" required>
      
    </div>

<button name="signin" class="btn btn-block btn-success">Proceed</button>

  </form>

  <!-- End Login tab -->

</div>

  <!-- Signup tab -->

  <div class="tab-pane fade" id="signup" role="tabpanel" aria-labelledby="signup-tab">

    <h5 class="login">Create an account</h5> 

    <form id="sup" method="post">

      <label>Full Name</label>

      <div class="input-group mb-2">

  <div class="input-group-prepend">

    <button class="btn btn-success"><i class="fa fa-user"></i></button>

  </div>

      <input type="text" id="userFn" class="form-control" value="<?php if(isset($_SESSION['fname'])) { echo $_SESSION['fname']; }?>" placeholder="* Full Name" name="fname"required>

    </div>

    <label>Student Email</label>

    <div class="input-group mb-2">

  <div class="input-group-prepend">

    <button class="btn btn-success"><i class="fa fa-envelope"></i></button>

  </div>

      <input type="email" id="userEm" class="form-control" value="<?php if(isset($_SESSION['email'])) { echo $_SESSION['email']; }?>" placeholder="* Must include @st.futminna.edu.ng" name="email" required>

      
    </div>

    <label>Department</label>

    <div class="input-group mb-2">

  <div class="input-group-prepend">

    <button class="btn btn-success"><i class="fa fa-envelope"></i></button>

  </div>

      <select name="dept" class="form-control">

        <option value="IMT">IMT</option>

        <option value="CSS">CSS</option>

        <option value="CPT">CPT</option>

      </select>
      
    </div>

     <label>Signup As?</label>

    <div class="input-group mb-2">

  <div class="input-group-prepend">

    <button class="btn btn-success"><i class="fa fa-envelope"></i></button>

  </div>

      <select name="type" class="form-control">

        <option value="Student">Student</option>

        <option value="Staff">Staff</option>

      </select>
      
    </div>

    <label>Password</label>

    <div class="input-group has-f-f mb-2">

  <div class="input-group-prepend">

    <button class="btn btn-success"><i class="fa fa-lock"></i></button>

  </div>

      <input type="password" id="userPw" class="form-control" placeholder="* Password" name="password" required>

      <div id="fback" class="invalid-feedback"><strong>Capslock is on.</strong></div>

    </div>

<button id="new-user" name="reg" class="trans-nr btn btn-block btn-success">Register</button>

  </form>

<!-- End signup tab -->

  </div>

  <!-- End All -->

</div>

</div>

</div>

</div>

<!-- Script -->

<script>

  $('.close').click(function() {

    $('#reg-s').fadeOut(1300);
  });

  function check_email(str) {

if(str === "") {

    $('#v_em').html("");

    return;
}

else {

    $.ajax({

        type:'GET',

        url:'ajax_sigin.php',

        data:'email='+str,

        success: function(html) {

            $('#v_em').append(html);
        }
});
}
}

function check_mobile(str) {

if(str === "") {

    $('#v_mb').html("");

    return;
}

else {

    $.ajax({

        type:'GET',

        url:'ajax_sigin.php',

        data:'mobile='+str,

        success: function(html) {

            $('#v_mb').append(html);
        }
});
}
}

function check_name(str) {

if(str === "") {

    $('#v_fn').html("");

    return;
}

else {

    $.ajax({

        type:'GET',

        url:'ajax_sigin.php',

        data:'fname='+str,

        success: function(html) {

            $('#v_fn').append(html);
        }
});
}
}

$('#c-pass').click(function() {

  var pass = document.getElementById('user_pw');

  if(pass.type === "password") {

    pass.type = "text";

    $('#c-pass').html("<i class='fa fa-eye-slash'></i>");
  }

  else {

    pass.type = "password";

    $('#c-pass').html("<i class='fa fa-eye'></i>");
  }
});

$('#c-pass2').click(function() {

  var pass = document.getElementById('userPw');

  if(pass.type === "password") {

    pass.type = "text";

    $('#c-pass2').html("<i class='fa fa-eye-slash'></i>");
  }

  else {

    pass.type = "password";

    $('#c-pass2').html("<i class='fa fa-eye'></i>");
  }
});

$('#termsAgree').click(function() {

$('#termsAgree').attr('disabled',true);

$('#new-user').removeAttr('disabled');

$('#new-user').removeClass('dis-btn');

});

</script>

